@echo off
REM Test fixture: reports __change_me as 0=even on even minutes and 1=odd on odd ones, so a re-detection has something to show.
for /f "tokens=2 delims=:" %%m in ("%TIME%") do set MINUTE=%%m
set /a PARITY=%MINUTE:~-1% %% 2
if %PARITY%==0 (
    echo {"virtual_packages": {"__change_me": {"version": "0", "build_string": "even"}}, "cache": {"ttl_seconds": 0}}
) else (
    echo {"virtual_packages": {"__change_me": {"version": "1", "build_string": "odd"}}, "cache": {"ttl_seconds": 0}}
)
exit /b 0
