@echo off
REM Test fixture: reports fixed verdicts for the virtual packages this channel registers foobar-detect for, so detection can be exercised without the hardware. Real plugins inspect the system here.
echo {"virtual_packages": {"__foobar": {"version": "1.2.3"}, "__foobar_arch": {"version": "0", "build_string": "gen4"}}, "cache": {"ttl_seconds": 3600}}
exit /b 0
