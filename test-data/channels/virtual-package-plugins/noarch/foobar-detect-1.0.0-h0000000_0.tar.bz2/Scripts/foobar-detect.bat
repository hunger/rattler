@echo off
REM Test fixture: see bin/foobar-detect for what this is.
echo {"kind": "present", "name": "__foobar", "version": "1.2.3"}
echo {"kind": "present", "name": "__foobar_arch", "version": "0", "build_string": "gen4"}
echo {"kind": "cache", "ttl_seconds": 3600}
exit /b 0
